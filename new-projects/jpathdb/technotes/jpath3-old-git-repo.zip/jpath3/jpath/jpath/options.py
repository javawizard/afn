
static_typing = False