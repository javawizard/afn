
class Binder(object):
    def bind_module(self, name):
        raise NotImplementedError
    
    def set_interpreter(self, interpreter):
        pass